from flask import Flask, request
import gspread
from oauth2client.service_account import ServiceAccountCredentials
from twilio.twiml.messaging_response import MessagingResponse

app = Flask(__name__)

# Autenticando com Google Sheets
scope = ["https://spreadsheets.google.com/feeds", "https://www.googleapis.com/auth/drive"]
creds = ServiceAccountCredentials.from_json_keyfile_name("credenciais.json", scope)
client = gspread.authorize(creds)

# Nome da planilha e aba
SHEET_NAME = "gastos mensais"
SHEET_TAB = "página 1"

@app.route("/webhook", methods=["POST"])
def webhook():
    incoming_msg = request.values.get("Body", "").strip()
    parts = [p.strip() for p in incoming_msg.split(",")]

    if len(parts) != 4:
        resp = MessagingResponse()
        resp.message("Formato inválido. Envie: Categoria, Valor, Descrição, Data")
        return str(resp)

    categoria, valor, descricao, data = parts

    try:
        sheet = client.open(SHEET_NAME).worksheet(SHEET_TAB)
        sheet.append_row([categoria, valor, descricao, data])
        resp = MessagingResponse()
        resp.message("Adicionado com sucesso!")
    except Exception as e:
        resp = MessagingResponse()
        resp.message(f"Erro ao salvar: {e}")

    return str(resp)